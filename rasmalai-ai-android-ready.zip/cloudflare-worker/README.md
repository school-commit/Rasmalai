# Rasmalai API Worker

Deploy `worker.js` to the existing Cloudflare Worker `jyoti-ai-api` so the app keeps using the same URL:
`https://jyoti-ai-api.aditya543maurya.workers.dev/`

Required secret: `GEMINI_API_KEY`
Model: `gemini-3.5-flash-lite`

The worker accepts the app's `messages`, `profile`, and `responseStyle` fields and forwards Gemini's native SSE JSON shape because the frontend parser expects `candidates[0].content.parts[].text`.
